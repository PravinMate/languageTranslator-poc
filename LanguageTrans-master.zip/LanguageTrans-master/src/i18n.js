import i18n from 'i18next';
import Backend from 'i18next-http-backend';//translation language files -public/locales/{lang}/translation.json
// import Cache from 'i18next-localstorage-cache';
// import postProcessor from 'i18next-sprintf-postprocessor';
import LanguageDetector from 'i18next-browser-languagedetector';
import {initReactI18next} from 'react-i18next'

i18n
  .use(Backend)
  .use(initReactI18next)
//   .use(Cache)
  .use(LanguageDetector)
//   .use(postProcessor)
  .init({
    fallbackLng:"en",//by default it will en menas english lang
    debug:true, //allow debuging mode it must false on production env
    //we need to initialise with couple of objects
    interpolation:{
        escapeValue:false //to avoid cross side scripting issues
    }
  });

  export default i18n;
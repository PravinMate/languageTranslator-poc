import { Card, Col, Row } from 'antd';
import React from 'react'
import { useTranslation } from 'react-i18next';


const Greetings = () => {
    const {t}= useTranslation();

  return (
    <div>
   
     <Row gutter={16}>
    <Col span={6}>
   
    </Col>
    <Col span={10}>
      <Card className='mt-1'>
      <h2>{t('Good Morning')}</h2>
      <hr/>
     <h5>{t('language')}</h5>
      </Card>
    </Col>
    <Col span={6}>
     
    </Col>
  </Row>
    </div>


  )
}

export default Greetings;


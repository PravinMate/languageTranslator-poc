import './App.css';
import i18n from './i18n';
import { Suspense, useEffect, useState } from 'react';
import Greetings from './Greetings';
import LocaleContext from './LocaleContext';
import { Card, Col, Row } from 'antd';


function Loading() {
  return (
    <>Loading...</>
  )
}


function App() {

  const [locale, setLocale] = useState(i18n.language);

  useEffect(() => {
    // Listen for language changes
    const languageChanged = (lang) => setLocale(lang);
    i18n.on('languageChanged', languageChanged);

    // Clean up the event listener when the component unmounts
    return () => {
      i18n.off('languageChanged', languageChanged);
    };
  }, []);
  function handleChange(event) {
    i18n.changeLanguage(event.target.value);
  }
  return (
    <div className="">
    
        <LocaleContext.Provider value={{ locale, setLocale }}>
        <Card className='App'>
          <Suspense fallback={<Loading />}>
       
            <div className='d-flex '>
              <div className='col-md-4'>

              </div>
           
              <div className='col-md-4 mt-5 me-1'>
                <h1 className='text-white'>Language Translator</h1>
                <div className='d-flex'>
                
                  <div className='col mt-5 '>
                    <h3 className='text-white'>Select Language:</h3>
                  </div>
                  <div className='col ms-4'>
                    <select className='form-control mt-5  'style={{width:"150px"}} value={locale} onChange={handleChange}>
                      <option value="en">English</option>
                      <option value="ja">Japanese</option>
                      <option value="es">Spanish</option>
                      <option value="fr">French</option>
                      <option value="zh">Chinese</option>
                      <option value="ar">Arabic</option>
                      <option value="de">German</option>
                      <option value="ko">Korean</option>

                    </select>
                  </div>
                </div>


              </div>


              <div className='col-md-4'>

              </div>


            </div>
            <Greetings />
            
     
          </Suspense>
          </Card>
        </LocaleContext.Provider>



    </div>
  );
}

export default App;
